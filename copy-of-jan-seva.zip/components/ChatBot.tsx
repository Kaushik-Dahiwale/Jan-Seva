import React, { useState, useRef, useEffect } from 'react';
import { MessageSquare, X, Send, Bot, User, Loader2, Sparkles } from 'lucide-react';
import { GoogleGenAI, Chat } from "@google/genai";

export const ChatBot = () => {
  const [isOpen, setIsOpen] = useState(false);
  // Updated initial greeting to be more directive about UI elements
  const [messages, setMessages] = useState<{ role: 'user' | 'model'; text: string }[]>([
    { 
      role: 'model', 
      text: 'Namaste! I am Jan Seva Sahayak. I can help you navigate this portal. Please note: To file a grievance, you must use the "Submit Complaint" button on the dashboard. To check progress, use the "Track Status" button. How can I help you today?' 
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatSessionRef = useRef<Chat | null>(null);

  // Initialize Chat Session
  useEffect(() => {
    const initChat = async () => {
        if (!chatSessionRef.current) {
            try {
                // Safe access to API KEY
                const apiKey = (window as any).process?.env?.API_KEY || '';
                if (!apiKey) {
                    console.warn("API Key not found in process.env");
                    // We don't throw here to avoid crashing the UI, just chat won't work
                    return; 
                }
                const ai = new GoogleGenAI({ apiKey });
                chatSessionRef.current = ai.chats.create({
                    model: 'gemini-3-flash-preview',
                    config: {
                        systemInstruction: `You are "Jan Seva Sahayak", a smart and empathetic AI assistant for the Jan Seva citizen grievance portal.
                        
                        **YOUR PRIMARY ROLE:**
                        1. Guide citizens to the correct buttons on the screen.
                        2. Explain government departments (PWD, Health, Police, etc.).
                        3. Clarify the status of a complaint (Submitted -> Assigned -> Resolved).

                        **CRITICAL UI INSTRUCTIONS (YOU MUST SAY THIS):**
                        - If a user tries to file a complaint here (e.g., "There is a pothole"), you MUST say: "I cannot record complaints in this chat. Please close this chat and click the large blue 'Submit Complaint' button on the main screen to officially file your report."
                        - If a user asks where to check status, say: "Please click the 'Track Status' button on the home screen and enter your Complaint Number."

                        **EMERGENCY PROTOCOL:**
                        - If the user mentions fire, accidents, crime in progress, or medical emergencies, tell them to STOP and dial 100, 101, or 102 immediately.
                        
                        Keep your answers short, professional, and helpful.`,
                    },
                });
            } catch (error) {
                console.error("Failed to initialize chat", error);
            }
        }
    };
    initChat();
  }, []);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isOpen]);

  const handleSend = async () => {
    if (!inputValue.trim() || isLoading) return;

    const userMsg = inputValue;
    setInputValue('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsLoading(true);

    try {
      // Re-initialize if missing or failed previously
      if (!chatSessionRef.current) {
         const apiKey = (window as any).process?.env?.API_KEY || '';
         if (!apiKey) throw new Error("API Key missing");
         
         const ai = new GoogleGenAI({ apiKey });
         chatSessionRef.current = ai.chats.create({
            model: 'gemini-3-flash-preview',
            config: { systemInstruction: 'You are a helpful assistant for Jan Seva.' }
         });
      }

      const streamResult = await chatSessionRef.current.sendMessageStream({ message: userMsg });
      
      let fullResponse = "";
      setMessages(prev => [...prev, { role: 'model', text: '' }]); // Placeholder

      for await (const chunk of streamResult) {
        const text = chunk.text;
        if (text) {
             fullResponse += text;
             setMessages(prev => {
                const newMsgs = [...prev];
                newMsgs[newMsgs.length - 1].text = fullResponse;
                return newMsgs;
             });
        }
      }
    } catch (error) {
      console.error("Chat error:", error);
      setMessages(prev => [...prev, { role: 'model', text: "I apologize, but I am unable to connect to the server right now. Please check your internet connection." }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`fixed bottom-6 right-6 z-[60] p-4 rounded-full shadow-2xl transition-all duration-300 hover:scale-110 flex items-center justify-center ${isOpen ? 'bg-slate-800 rotate-90' : 'bg-brand-600 hover:bg-brand-700'} ring-4 ring-white/20`}
        aria-label="Toggle Chat"
      >
        {isOpen ? <X className="w-7 h-7 text-white" /> : <MessageSquare className="w-7 h-7 text-white" />}
      </button>

      {/* Chat Window Container */}
      <div 
        className={`fixed bottom-24 right-4 sm:right-6 w-[calc(100vw-32px)] sm:w-[380px] bg-white rounded-2xl shadow-2xl border border-slate-200 z-[60] flex flex-col transition-all duration-300 origin-bottom-right ${isOpen ? 'scale-100 opacity-100 translate-y-0' : 'scale-90 opacity-0 translate-y-4 pointer-events-none'}`}
        style={{ height: '550px', maxHeight: '75vh' }}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-brand-600 to-brand-800 p-4 rounded-t-2xl flex items-center gap-3 shadow-md relative overflow-hidden">
          <div className="absolute top-0 right-0 p-4 opacity-10">
             <MessageSquare className="w-24 h-24 text-white transform rotate-12" />
          </div>
          <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm border border-white/20 relative z-10">
             <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div className="relative z-10">
            <h3 className="font-bold text-white text-lg tracking-tight">Jan Seva Sahayak</h3>
            <p className="text-brand-100 text-xs flex items-center gap-1.5 font-medium">
              <span className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse shadow-[0_0_8px_rgba(52,211,153,0.8)]"></span>
              Online
            </p>
          </div>
        </div>

        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50/50 scroll-smooth">
          {messages.map((msg, idx) => (
            <div key={idx} className={`flex gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 shadow-sm border ${
                msg.role === 'user' 
                ? 'bg-white border-slate-200' 
                : 'bg-brand-50 border-brand-200'
              }`}>
                {msg.role === 'user' ? <User className="w-4 h-4 text-slate-600" /> : <Bot className="w-4 h-4 text-brand-600" />}
              </div>
              <div 
                className={`max-w-[85%] p-3.5 rounded-2xl text-sm leading-relaxed shadow-sm ${
                  msg.role === 'user' 
                    ? 'bg-brand-600 text-white rounded-tr-none' 
                    : 'bg-white border border-slate-200 text-slate-700 rounded-tl-none'
                }`}
              >
                {msg.text}
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex gap-3">
               <div className="w-8 h-8 rounded-full bg-brand-50 flex items-center justify-center flex-shrink-0 border border-brand-200">
                  <Bot className="w-4 h-4 text-brand-600" />
               </div>
               <div className="bg-white border border-slate-200 px-4 py-3 rounded-2xl rounded-tl-none shadow-sm flex items-center gap-2">
                 <Loader2 className="w-4 h-4 text-brand-600 animate-spin" />
                 <span className="text-xs text-slate-500 font-medium">Thinking...</span>
               </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="p-4 bg-white border-t border-slate-100 rounded-b-2xl">
          <div className="relative flex items-center gap-2">
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={handleKeyPress}
              placeholder="Ask for help..."
              className="w-full pl-4 pr-12 py-3.5 bg-slate-50 border border-slate-200 focus:bg-white focus:border-brand-500 rounded-xl outline-none text-sm transition-all shadow-inner focus:shadow-brand-100"
            />
            <button 
              onClick={handleSend}
              disabled={!inputValue.trim() || isLoading}
              className="absolute right-2 p-2 bg-brand-600 text-white rounded-lg disabled:opacity-50 disabled:cursor-not-allowed hover:bg-brand-700 transition-colors shadow-md hover:shadow-lg active:scale-95 transform"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </>
  );
};