import React from 'react';
import { Check, ArrowRight, Home } from 'lucide-react';
import { ViewState } from '../types';

interface SuccessProps {
  onNavigate: (view: ViewState) => void;
}

export const Success: React.FC<SuccessProps> = ({ onNavigate }) => {
  return (
    <div className="min-h-[80vh] flex flex-col items-center justify-center p-6">
      <div className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center mb-6 animate-bounce">
        <Check className="w-10 h-10 text-emerald-600 stroke-[3px]" />
      </div>

      <h1 className="text-3xl font-bold text-slate-900 mb-2 text-center">Complaint Submitted!</h1>
      <p className="text-slate-500 text-center mb-8">Your voice has been recorded.</p>

      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm w-full max-w-sm mb-8">
        <div className="flex justify-between items-center mb-4 pb-4 border-b border-slate-100">
          <span className="text-sm text-slate-500">Ticket ID</span>
          <span className="font-mono font-bold text-slate-900">GRV-2024-8829</span>
        </div>
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm text-slate-500">Department</span>
          <span className="font-semibold text-brand-700">PWD</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-sm text-slate-500">ETA</span>
          <span className="font-semibold text-slate-900">3 Days</span>
        </div>
      </div>

      <div className="flex flex-col w-full max-w-sm gap-3">
        <button
          onClick={() => onNavigate('track')}
          className="w-full flex items-center justify-center gap-2 bg-brand-600 hover:bg-brand-700 text-white py-4 rounded-xl font-semibold shadow-lg shadow-brand-500/20 transition-all"
        >
          Track Progress
          <ArrowRight className="w-5 h-5" />
        </button>
        <button
          onClick={() => onNavigate('landing')}
          className="w-full flex items-center justify-center gap-2 bg-white hover:bg-slate-50 text-slate-700 py-4 rounded-xl font-semibold border border-slate-200 transition-all"
        >
          <Home className="w-5 h-5" />
          Back to Home
        </button>
      </div>
    </div>
  );
};
