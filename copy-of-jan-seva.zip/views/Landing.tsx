import React from 'react';
import { FileText, Search, ShieldCheck, ArrowRight } from 'lucide-react';
import { ViewState } from '../types';
import { ChatBot } from '../components/ChatBot';

interface LandingProps {
  onNavigate: (view: ViewState) => void;
}

export const Landing: React.FC<LandingProps> = ({ onNavigate }) => {
  return (
    <div className="flex flex-col items-center min-h-screen">
      {/* Hero Section */}
      <div className="w-full bg-gradient-to-b from-brand-50 to-white py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-100 text-brand-700 text-sm font-medium mb-6 animate-fade-in-up">
            <ShieldCheck className="w-4 h-4" />
            <span>Official Government Service Portal</span>
          </div>
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold text-slate-900 tracking-tight mb-6">
            Your Voice, <span className="text-brand-600">Our Action.</span>
          </h1>
          <p className="text-lg sm:text-xl text-slate-600 mb-10 max-w-2xl mx-auto leading-relaxed">
            Report issues, track progress, and improve your community. 
            The easiest way to connect with your local administration.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 w-full max-w-lg mx-auto">
            <button
              onClick={() => onNavigate('submit')}
              className="w-full group relative flex items-center justify-center gap-3 bg-brand-600 hover:bg-brand-700 text-white px-8 py-4 rounded-xl text-lg font-semibold shadow-xl shadow-brand-500/20 transition-all duration-300 hover:-translate-y-1"
            >
              <FileText className="w-5 h-5" />
              Submit Complaint
              <ArrowRight className="w-5 h-5 opacity-0 -ml-2 group-hover:opacity-100 group-hover:ml-0 transition-all duration-300" />
            </button>
            
            <button
              onClick={() => onNavigate('track')}
              className="w-full flex items-center justify-center gap-3 bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 hover:border-slate-300 px-8 py-4 rounded-xl text-lg font-semibold shadow-sm transition-all duration-300"
            >
              <Search className="w-5 h-5" />
              Track Status
            </button>
          </div>
        </div>
      </div>

      {/* Features Grid */}
      <div className="max-w-7xl mx-auto px-4 py-16 grid grid-cols-1 md:grid-cols-3 gap-8 pb-32">
        {[
          { icon: '🎙️', title: 'Voice Support', desc: 'Speak your complaint in your local language.' },
          { icon: '📸', title: 'Visual Evidence', desc: 'Upload photos or videos for faster resolution.' },
          { icon: '🤖', title: 'AI Processing', desc: 'Automatic categorization and department routing.' },
        ].map((feature, idx) => (
          <div key={idx} className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow">
            <div className="text-3xl mb-4">{feature.icon}</div>
            <h3 className="text-lg font-bold text-slate-900 mb-2">{feature.title}</h3>
            <p className="text-slate-500">{feature.desc}</p>
          </div>
        ))}
      </div>

      {/* AI Chatbot */}
      <ChatBot />
    </div>
  );
};