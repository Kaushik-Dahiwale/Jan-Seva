import React, { useState } from 'react';
import { Mic, MapPin, Image as ImageIcon, Camera, X, ArrowRight, Loader2 } from 'lucide-react';
import { ViewState } from '../types';

interface SubmitProps {
  onNavigate: (view: ViewState) => void;
}

export const SubmitGrievance: React.FC<SubmitProps> = ({ onNavigate }) => {
  const [isRecording, setIsRecording] = useState(false);
  const [step, setStep] = useState(1);
  const [text, setText] = useState('');

  const handleNext = () => {
    onNavigate('processing');
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-slate-900">New Complaint</h2>
        <p className="text-slate-500">Share the details of the issue you are facing.</p>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        {/* Step Indicator */}
        <div className="bg-slate-50 px-6 py-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="flex items-center justify-center w-6 h-6 rounded-full bg-brand-600 text-white text-xs font-bold">1</span>
            <span className="text-sm font-semibold text-slate-700">Details</span>
          </div>
           <div className="h-px w-12 bg-slate-300 mx-2"></div>
           <div className="flex items-center gap-2 opacity-50">
            <span className="flex items-center justify-center w-6 h-6 rounded-full bg-slate-200 text-slate-600 text-xs font-bold">2</span>
            <span className="text-sm font-semibold text-slate-700">Review</span>
          </div>
        </div>

        <div className="p-6 space-y-6">
          
          {/* Text Input */}
          <div className="space-y-2">
            <label className="block text-sm font-medium text-slate-700">Describe the Issue</label>
            <textarea
              className="w-full min-h-[120px] p-4 rounded-xl border border-slate-200 focus:border-brand-500 focus:ring-2 focus:ring-brand-200 outline-none transition-all resize-none text-slate-800"
              placeholder="e.g., Pothole on MG Road causing heavy traffic..."
              value={text}
              onChange={(e) => setText(e.target.value)}
            ></textarea>
          </div>

          {/* Voice Input */}
          <div className="space-y-2">
             <label className="block text-sm font-medium text-slate-700">Or Speak (Multilingual)</label>
             <button
              onClick={() => setIsRecording(!isRecording)}
              className={`w-full flex items-center justify-center gap-3 py-6 rounded-xl border-2 border-dashed transition-all ${
                isRecording 
                  ? 'border-red-400 bg-red-50 text-red-600' 
                  : 'border-slate-200 hover:border-brand-400 hover:bg-slate-50 text-slate-600'
              }`}
            >
              <div className={`p-3 rounded-full ${isRecording ? 'bg-red-100 animate-pulse' : 'bg-slate-100'}`}>
                <Mic className="w-6 h-6" />
              </div>
              <span className="font-medium">
                {isRecording ? 'Listening... Tap to stop' : 'Tap to Record Voice'}
              </span>
            </button>
          </div>

          {/* Media Upload */}
          <div className="space-y-2">
            <label className="block text-sm font-medium text-slate-700">Evidence (Optional)</label>
            <div className="grid grid-cols-2 gap-4">
              <button className="flex flex-col items-center justify-center gap-2 p-4 rounded-xl border border-slate-200 hover:bg-slate-50 transition-colors text-slate-600">
                <Camera className="w-6 h-6 text-brand-500" />
                <span className="text-xs font-medium">Take Photo</span>
              </button>
              <button className="flex flex-col items-center justify-center gap-2 p-4 rounded-xl border border-slate-200 hover:bg-slate-50 transition-colors text-slate-600">
                <ImageIcon className="w-6 h-6 text-brand-500" />
                <span className="text-xs font-medium">Upload File</span>
              </button>
            </div>
          </div>

          {/* Location */}
          <div className="space-y-2">
            <label className="block text-sm font-medium text-slate-700">Location</label>
            <div className="flex items-center gap-3 p-3 bg-brand-50 rounded-xl border border-brand-100 text-brand-700">
              <MapPin className="w-5 h-5 flex-shrink-0" />
              <div className="flex-grow">
                <p className="text-sm font-semibold">Detected Location</p>
                <p className="text-xs opacity-80">Sector 4, Rohini, Delhi (GPS)</p>
              </div>
              <button className="text-xs font-bold underline">Change</button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-100 flex justify-end">
          <button
            onClick={handleNext}
            disabled={!text && !isRecording}
            className={`flex items-center gap-2 px-6 py-3 rounded-xl font-semibold shadow-lg transition-all ${
              (!text && !isRecording) 
                ? 'bg-slate-300 text-slate-500 cursor-not-allowed' 
                : 'bg-brand-600 text-white hover:bg-brand-700 hover:-translate-y-1 shadow-brand-500/30'
            }`}
          >
            Submit Complaint
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
