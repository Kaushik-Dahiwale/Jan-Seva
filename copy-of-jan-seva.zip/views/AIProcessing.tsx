import React, { useEffect, useState } from 'react';
import { BrainCircuit, Check, FileText, Mic, MapPin, Server, Sparkles } from 'lucide-react';
import { ViewState } from '../types';

interface ProcessingProps {
  onNavigate: (view: ViewState) => void;
}

export const AIProcessing: React.FC<ProcessingProps> = ({ onNavigate }) => {
  const [step, setStep] = useState(0);
  
  const steps = [
    { label: 'Analysing inputs (Text, Voice, Media)', duration: 1500 },
    { label: 'Identifying Grievance Category', duration: 1500 },
    { label: 'Routing to Public Works Dept (PWD)', duration: 1500 },
    { label: 'Generating Official Ticket ID', duration: 1000 },
  ];

  useEffect(() => {
    let isMounted = true;
    
    const runSteps = async () => {
      for (let i = 0; i < steps.length; i++) {
        if (!isMounted) return;
        setStep(i);
        await new Promise(r => setTimeout(r, steps[i].duration));
      }
      if (isMounted) onNavigate('success');
    };

    runSteps();

    return () => { isMounted = false; };
  }, [onNavigate]);

  return (
    <div className="min-h-[80vh] flex flex-col items-center justify-center p-6 bg-slate-50 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 z-0 opacity-30">
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-brand-200 rounded-full mix-blend-multiply filter blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-blue-200 rounded-full mix-blend-multiply filter blur-3xl animate-pulse" style={{ animationDelay: '1s' }}></div>
      </div>

      <div className="relative z-10 flex flex-col items-center w-full max-w-lg">
        
        {/* Central Animation Hub */}
        <div className="relative w-48 h-48 mb-12 flex items-center justify-center">
          {/* Pulsing Rings */}
          <div className="absolute inset-0 border-4 border-brand-100 rounded-full animate-[ping_3s_ease-in-out_infinite]"></div>
          <div className="absolute inset-4 border-2 border-brand-200 rounded-full animate-[ping_3s_ease-in-out_infinite]" style={{ animationDelay: '0.5s' }}></div>
          
          {/* Rotating Orbit Ring */}
          <div className="absolute inset-0 rounded-full border border-slate-200 animate-[spin_10s_linear_infinite]">
             <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-white p-1.5 rounded-full shadow-sm border border-slate-100">
               <FileText className="w-4 h-4 text-slate-400" />
             </div>
             <div className="absolute top-1/2 -right-3 -translate-y-1/2 bg-white p-1.5 rounded-full shadow-sm border border-slate-100">
               <Mic className="w-4 h-4 text-slate-400" />
             </div>
             <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 bg-white p-1.5 rounded-full shadow-sm border border-slate-100">
               <MapPin className="w-4 h-4 text-slate-400" />
             </div>
             <div className="absolute top-1/2 -left-3 -translate-y-1/2 bg-white p-1.5 rounded-full shadow-sm border border-slate-100">
               <Server className="w-4 h-4 text-slate-400" />
             </div>
          </div>

          {/* Central Brain */}
          <div className="relative z-20 w-24 h-24 bg-white rounded-2xl shadow-xl flex items-center justify-center border border-slate-100">
             <div className="absolute inset-0 bg-brand-50 rounded-2xl animate-pulse"></div>
             <BrainCircuit className="w-12 h-12 text-brand-600 relative z-10" />
             
             {/* Sparkles appearing randomly */}
             <div className="absolute -top-2 -right-2 animate-bounce">
                <Sparkles className="w-5 h-5 text-yellow-400 fill-yellow-400" />
             </div>
          </div>
        </div>

        {/* Dynamic Status Steps */}
        <div className="w-full space-y-4 bg-white/60 backdrop-blur-sm p-6 rounded-2xl border border-white/50 shadow-sm">
          {steps.map((s, idx) => (
            <div key={idx} className={`flex items-center gap-4 transition-all duration-500 ${
              idx === step ? 'scale-105 opacity-100' : 
              idx < step ? 'opacity-50' : 'opacity-40'
            }`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center transition-colors duration-300 ${
                idx < step ? 'bg-emerald-100 text-emerald-600' :
                idx === step ? 'bg-brand-100 text-brand-600' :
                'bg-slate-100 text-slate-400'
              }`}>
                {idx < step ? <Check className="w-5 h-5" /> : 
                 idx === step ? <div className="w-2.5 h-2.5 bg-brand-600 rounded-full animate-ping" /> :
                 <div className="w-2 h-2 bg-slate-300 rounded-full" />
                }
              </div>
              <div>
                <p className={`font-semibold text-sm ${idx === step ? 'text-brand-900' : 'text-slate-700'}`}>
                  {s.label}
                </p>
                {idx === step && (
                  <p className="text-xs text-brand-600 animate-pulse">Processing...</p>
                )}
              </div>
            </div>
          ))}
        </div>
        
      </div>
    </div>
  );
};