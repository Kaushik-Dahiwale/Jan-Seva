import React from 'react';
import { ArrowLeft, Clock, MapPin, AlertCircle, MessageSquare, ExternalLink, FileText, UserCheck, Hammer, CheckCircle, Check } from 'lucide-react';
import { ViewState } from '../types';
import { MOCK_GRIEVANCE } from '../constants';

interface TrackProps {
  onNavigate: (view: ViewState) => void;
}

const STEPS = [
  { id: 'Submitted', label: 'Submitted', icon: FileText },
  { id: 'Assigned', label: 'Assigned', icon: UserCheck },
  { id: 'In Progress', label: 'In Progress', icon: Hammer },
  { id: 'Resolved', label: 'Resolved', icon: CheckCircle },
];

export const Track: React.FC<TrackProps> = ({ onNavigate }) => {
  const g = MOCK_GRIEVANCE;
  const currentStepIndex = STEPS.findIndex(s => s.id === g.status);

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 animate-fade-in-up">
      <button 
        onClick={() => onNavigate('landing')}
        className="flex items-center gap-2 text-slate-500 hover:text-brand-600 mb-6 transition-colors font-medium"
      >
        <ArrowLeft className="w-4 h-4" /> Back to Home
      </button>

      {/* Header Card with ID and Status */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 mb-8">
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
          <div>
            <div className="flex flex-wrap items-center gap-3 mb-2">
              <h1 className="text-3xl font-bold text-slate-900">{g.id}</h1>
              <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider
                ${g.status === 'Resolved' ? 'bg-emerald-100 text-emerald-700' : 
                  g.status === 'In Progress' ? 'bg-blue-100 text-blue-700' :
                  'bg-slate-100 text-slate-700'}`}>
                {g.status}
              </span>
            </div>
            <p className="text-slate-500 flex items-center gap-2 text-sm">
              <Clock className="w-4 h-4" /> Submitted on {g.dateSubmitted}
            </p>
          </div>
          
          <div className="flex gap-4">
             <div className="bg-slate-50 px-4 py-3 rounded-xl border border-slate-100">
               <p className="text-xs text-slate-400 uppercase font-bold mb-1">Estimated Completion</p>
               <p className="text-lg font-bold text-slate-900">{g.eta}</p>
             </div>
          </div>
        </div>

        {/* Visual Stepper */}
        <div className="mt-10 mb-4 relative px-4">
          {/* Progress Bar Background */}
          <div className="absolute top-1/2 left-0 w-full h-1 bg-slate-100 -translate-y-1/2 rounded-full z-0"></div>
          
          {/* Active Progress Bar */}
          <div 
            className="absolute top-1/2 left-0 h-1 bg-brand-500 -translate-y-1/2 rounded-full transition-all duration-1000 ease-out z-0"
            style={{ width: `${(currentStepIndex / (STEPS.length - 1)) * 100}%` }}
          ></div>

          <div className="relative z-10 flex justify-between">
            {STEPS.map((step, idx) => {
              const isCompleted = idx <= currentStepIndex;
              const isCurrent = idx === currentStepIndex;
              const Icon = step.icon;

              return (
                <div key={idx} className="flex flex-col items-center">
                  <div className={`
                    w-12 h-12 rounded-full flex items-center justify-center border-4 transition-all duration-500
                    ${isCompleted 
                      ? 'bg-brand-600 border-brand-100 text-white shadow-lg shadow-brand-500/30 scale-110' 
                      : 'bg-white border-slate-200 text-slate-300'
                    }
                    ${isCurrent ? 'ring-4 ring-brand-100 ring-opacity-50' : ''}
                  `}>
                    {isCompleted && !isCurrent ? <Check className="w-6 h-6" /> : <Icon className="w-5 h-5" />}
                  </div>
                  <p className={`mt-3 text-xs font-bold uppercase tracking-wide transition-colors duration-300 ${isCompleted ? 'text-brand-700' : 'text-slate-400'}`}>
                    {step.label}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Main Content: Detailed Timeline */}
        <div className="lg:col-span-2 space-y-6">
           {/* Detailed Description */}
           <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wide mb-4">Grievance Details</h3>
              <p className="text-slate-700 leading-relaxed text-lg mb-4">
                "{g.description}"
              </p>
              <div className="flex flex-wrap gap-2">
                 <span className="px-3 py-1 bg-slate-100 text-slate-600 rounded-lg text-sm font-medium border border-slate-200">
                    {g.category}
                 </span>
                 <span className="px-3 py-1 bg-slate-100 text-slate-600 rounded-lg text-sm font-medium border border-slate-200 flex items-center gap-1">
                    <MapPin className="w-3 h-3" /> {g.location}
                 </span>
                 <span className="px-3 py-1 bg-red-50 text-red-600 rounded-lg text-sm font-medium border border-red-100 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" /> {g.priority} Priority
                 </span>
              </div>
           </div>

           {/* Activity Log */}
           <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
             <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wide mb-6">Activity Log</h3>
             <div className="space-y-8 pl-2">
                {g.timeline.map((event, idx) => (
                  <div key={idx} className="relative pl-8 border-l-2 border-slate-100 last:border-0 pb-2">
                    <div className={`absolute -left-[9px] top-0 w-4 h-4 rounded-full border-2 bg-white ${
                      event.status === 'completed' ? 'border-brand-500' : 'border-slate-300'
                    }`}></div>
                    <div>
                      <p className="text-xs text-slate-400 font-semibold mb-1">{event.date}</p>
                      <h4 className="text-slate-900 font-semibold">{event.title}</h4>
                      {event.description && <p className="text-slate-600 text-sm mt-1">{event.description}</p>}
                    </div>
                  </div>
                ))}
             </div>
           </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Officer Card */}
           {g.officer && (
            <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-brand-400 to-brand-600"></div>
              <h3 className="text-xs text-slate-400 uppercase font-bold mb-4">Assigned Officer</h3>
              <div className="flex items-center gap-4 mb-6">
                <img src={g.officer.avatar} alt="Officer" className="w-14 h-14 rounded-full object-cover border-2 border-white shadow-md" />
                <div>
                  <p className="font-bold text-slate-900 text-lg">{g.officer.name}</p>
                  <p className="text-sm text-slate-500 font-medium">{g.officer.role}</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                 <button className="flex items-center justify-center gap-2 bg-brand-600 text-white py-2.5 rounded-xl text-sm font-semibold hover:bg-brand-700 transition-colors shadow-lg shadow-brand-500/20">
                   Call
                 </button>
                 <button className="flex items-center justify-center gap-2 bg-white text-slate-700 border border-slate-200 py-2.5 rounded-xl text-sm font-semibold hover:bg-slate-50 transition-colors">
                   Message
                 </button>
              </div>
            </div>
          )}

          {/* Quick Actions */}
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
             <h3 className="text-xs text-slate-400 uppercase font-bold mb-4">Quick Actions</h3>
             <div className="space-y-3">
               <button className="w-full flex items-center gap-3 p-3 rounded-xl border border-slate-200 hover:bg-slate-50 hover:border-slate-300 transition-all text-left group">
                 <div className="bg-orange-100 p-2.5 rounded-lg text-orange-600 group-hover:scale-110 transition-transform">
                   <Clock className="w-5 h-5" />
                 </div>
                 <div>
                   <p className="text-sm font-bold text-slate-700">Send Reminder</p>
                   <p className="text-xs text-slate-500">Notify officer about delay</p>
                 </div>
               </button>

               <button className="w-full flex items-center gap-3 p-3 rounded-xl border border-slate-200 hover:bg-slate-50 hover:border-slate-300 transition-all text-left group">
                 <div className="bg-blue-100 p-2.5 rounded-lg text-blue-600 group-hover:scale-110 transition-transform">
                   <MessageSquare className="w-5 h-5" />
                 </div>
                 <div>
                   <p className="text-sm font-bold text-slate-700">Add Information</p>
                   <p className="text-xs text-slate-500">Upload new photos/details</p>
                 </div>
               </button>

               <button className="w-full flex items-center gap-3 p-3 rounded-xl border border-slate-200 hover:bg-slate-50 hover:border-slate-300 transition-all text-left group">
                 <div className="bg-red-100 p-2.5 rounded-lg text-red-600 group-hover:scale-110 transition-transform">
                   <ExternalLink className="w-5 h-5" />
                 </div>
                 <div>
                   <p className="text-sm font-bold text-slate-700">Escalate Issue</p>
                   <p className="text-xs text-slate-500">Report to higher authority</p>
                 </div>
               </button>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};