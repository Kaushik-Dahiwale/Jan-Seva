import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { Filter, Download, MoreHorizontal, CheckCircle, Clock, AlertTriangle, ChevronRight } from 'lucide-react';
import { ADMIN_STATS, DEPARTMENT_DATA, RECENT_GRIEVANCES } from '../constants';
import { ViewState } from '../types';

interface AdminDashboardProps {
  onNavigate: (view: ViewState) => void; // Added for potential navigation
}

const StatCard = ({ title, value, trend, color, icon }: any) => (
  <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex items-start justify-between hover:shadow-md transition-shadow">
    <div>
      <p className="text-sm font-medium text-slate-500 mb-1">{title}</p>
      <h3 className="text-3xl font-bold text-slate-900 mb-2">{value}</h3>
      <span className={`inline-flex items-center text-xs font-semibold px-2 py-1 rounded-full ${trend.includes('+') ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
        {trend} vs last month
      </span>
    </div>
    <div className={`p-3 rounded-xl ${color}`}>
      {icon}
    </div>
  </div>
);

export const AdminDashboard: React.FC<AdminDashboardProps> = () => {
  return (
    <div className="p-6 max-w-[1600px] mx-auto animate-fade-in-up">
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Dashboard</h1>
          <p className="text-slate-500">Overview of public grievances and resolution performance.</p>
        </div>
        <div className="flex items-center gap-3">
           <span className="text-sm text-slate-500 hidden sm:block">Last updated: Just now</span>
           <button className="p-2 border border-slate-200 rounded-lg hover:bg-white bg-slate-50 transition-colors">
             <Filter className="w-4 h-4 text-slate-600" />
           </button>
           <button className="flex items-center gap-2 bg-brand-600 text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-brand-700 transition-colors shadow-lg shadow-brand-500/20">
             <Download className="w-4 h-4" /> Export Report
           </button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard 
          title="Total Complaints" 
          value={ADMIN_STATS.total} 
          trend="+12%" 
          color="bg-brand-50 text-brand-700"
          icon={<div className="w-2 h-2 rounded-full bg-brand-500"></div>}
        />
        <StatCard 
          title="Pending" 
          value={ADMIN_STATS.pending} 
          trend="-5%" 
          color="bg-yellow-50 text-yellow-700"
          icon={<Clock className="w-4 h-4 text-yellow-600" />}
        />
        <StatCard 
          title="Resolved" 
          value={ADMIN_STATS.resolved} 
          trend="+8%" 
          color="bg-emerald-50 text-emerald-700"
          icon={<CheckCircle className="w-4 h-4 text-emerald-600" />}
        />
        <StatCard 
          title="High Priority" 
          value={ADMIN_STATS.highPriority} 
          trend="+2%" 
          color="bg-red-50 text-red-700"
          icon={<AlertTriangle className="w-4 h-4 text-red-600" />}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
        {/* Chart Section */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm lg:col-span-2">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-bold text-slate-900">Department Breakdown</h3>
            <select className="text-sm border-none bg-slate-50 rounded-lg px-2 py-1 text-slate-600 outline-none cursor-pointer">
              <option>Last 30 Days</option>
              <option>Last Quarter</option>
            </select>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={DEPARTMENT_DATA}>
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} />
                <Tooltip 
                  cursor={{fill: '#f1f5f9'}} 
                  contentStyle={{borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}}
                />
                <Bar dataKey="tickets" radius={[4, 4, 0, 0]}>
                  {DEPARTMENT_DATA.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={['#3b82f6', '#0ea5e9', '#6366f1', '#8b5cf6'][index % 4]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Priority Actions */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col">
          <h3 className="font-bold text-slate-900 mb-4">Priority Actions</h3>
          <div className="space-y-4 flex-grow">
            {[
              { id: 'GRV-8801', title: 'Open Manhole', loc: 'Sector 4', time: '2h ago' },
              { id: 'GRV-8812', title: 'Water Contamination', loc: 'Block C', time: '5h ago' },
              { id: 'GRV-8845', title: 'Live Wire Fallen', loc: 'Market Rd', time: '1h ago' }
            ].map((item, idx) => (
              <div key={idx} className="flex gap-4 p-3 rounded-xl border border-slate-100 hover:bg-slate-50 transition-colors cursor-pointer group">
                <div className="w-10 h-10 rounded-full bg-red-100 flex-shrink-0 flex items-center justify-center text-red-600 font-bold text-xs border border-red-200">
                  HP
                </div>
                <div className="flex-grow">
                  <div className="flex justify-between items-start">
                    <h4 className="text-sm font-semibold text-slate-800">{item.title}</h4>
                    <span className="text-[10px] text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded">{item.id}</span>
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">{item.loc} • <span className="text-red-500 font-medium">{item.time}</span></p>
                </div>
                <div className="flex items-center justify-center text-slate-300 group-hover:text-brand-600 transition-colors">
                  <ChevronRight className="w-4 h-4" />
                </div>
              </div>
            ))}
          </div>
          <button className="w-full mt-4 py-2.5 text-sm font-semibold text-brand-600 bg-brand-50 rounded-lg hover:bg-brand-100 transition-colors">
            View All High Priority
          </button>
        </div>
      </div>

      {/* Recent Grievances Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <h3 className="font-bold text-slate-900">Recent Complaints</h3>
          <div className="flex gap-2">
            <button className="text-xs font-medium text-slate-600 hover:text-brand-600 px-3 py-1.5 rounded-lg hover:bg-white border border-transparent hover:border-slate-200 transition-all">All</button>
            <button className="text-xs font-medium text-slate-600 hover:text-brand-600 px-3 py-1.5 rounded-lg hover:bg-white border border-transparent hover:border-slate-200 transition-all">New</button>
            <button className="text-xs font-medium text-slate-600 hover:text-brand-600 px-3 py-1.5 rounded-lg hover:bg-white border border-transparent hover:border-slate-200 transition-all">Assigned</button>
          </div>
        </div>
        <div className="overflow-x-auto custom-scrollbar">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200">
                <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Complaint ID</th>
                <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Department</th>
                <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Category</th>
                <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Priority</th>
                <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Date</th>
                <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {RECENT_GRIEVANCES.map((row) => (
                <tr key={row.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-6 py-4 text-sm font-medium text-slate-900">{row.id}</td>
                  <td className="px-6 py-4 text-sm text-slate-600">{row.dept}</td>
                  <td className="px-6 py-4 text-sm text-slate-600">{row.category}</td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                      ${row.status === 'Resolved' ? 'bg-emerald-100 text-emerald-800' : ''}
                      ${row.status === 'In Progress' ? 'bg-blue-100 text-blue-800' : ''}
                      ${row.status === 'Assigned' ? 'bg-indigo-100 text-indigo-800' : ''}
                      ${row.status === 'Submitted' ? 'bg-slate-100 text-slate-800' : ''}
                    `}>
                      {row.status}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                     <span className={`inline-flex items-center gap-1.5 text-xs font-medium
                      ${row.priority === 'High' ? 'text-red-700' : ''}
                      ${row.priority === 'Medium' ? 'text-orange-700' : ''}
                      ${row.priority === 'Low' ? 'text-slate-600' : ''}
                    `}>
                      <span className={`w-1.5 h-1.5 rounded-full 
                        ${row.priority === 'High' ? 'bg-red-500' : ''}
                        ${row.priority === 'Medium' ? 'bg-orange-500' : ''}
                        ${row.priority === 'Low' ? 'bg-slate-400' : ''}
                      `}></span>
                      {row.priority}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-slate-500">{row.date}</td>
                  <td className="px-6 py-4 text-right">
                    <button className="text-slate-400 hover:text-slate-600 p-1 hover:bg-slate-100 rounded-lg transition-colors">
                      <MoreHorizontal className="w-5 h-5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};